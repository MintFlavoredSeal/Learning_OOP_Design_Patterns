package behavioral.Mediator.javaExample.components;

import behavioral.Mediator.javaExample.mediators.Mediator;

/**
 * Common component interface.
 */

public interface Component {
    void setMediator(Mediator mediator);
    String getName();
}